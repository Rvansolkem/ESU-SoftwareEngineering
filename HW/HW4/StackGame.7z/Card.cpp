#include "Card.h"

Card::Card(int i){rank=i;}

int Card::getRank(){return rank;}