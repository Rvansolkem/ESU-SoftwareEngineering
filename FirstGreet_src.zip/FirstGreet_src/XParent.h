// XParent.h: interface for the XParent class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_XPARENT_H__CD7DABD3_6B20_4228_8EED_D9FF1C7C77D7__INCLUDED_)
#define AFX_XPARENT_H__CD7DABD3_6B20_4228_8EED_D9FF1C7C77D7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class XParent  
{
public:
	XParent();
	virtual int whoami();
	virtual ~XParent();

};

#endif // !defined(AFX_XPARENT_H__CD7DABD3_6B20_4228_8EED_D9FF1C7C77D7__INCLUDED_)
