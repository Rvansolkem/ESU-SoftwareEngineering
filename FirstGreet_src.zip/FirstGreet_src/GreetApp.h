// GreetApp.h: interface for the GreetApp class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GREETAPP_H__EB163921_B594_4286_9648_389AC9801F95__INCLUDED_)
#define AFX_GREETAPP_H__EB163921_B594_4286_9648_389AC9801F95__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class GreetApp  
{
public:
	GreetApp();
	virtual ~GreetApp();

};

#endif // !defined(AFX_GREETAPP_H__EB163921_B594_4286_9648_389AC9801F95__INCLUDED_)
